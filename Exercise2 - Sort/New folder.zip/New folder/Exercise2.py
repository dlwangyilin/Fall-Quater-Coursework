import sys

import MySort
import time

def readFile(s):
    """
    :param self:
    :param s: pathname "test.txt"
    :return: list of words in the file
    """
    filename = s
    result = ""
    fhand = open(filename)
    for line in fhand:
        lst = list(line)
        for i in range(len(lst)):
            if (not lst[i].isalnum() and lst[i] != " "):
                lst[i] = " "
        for i in lst:
            result = result + i

    words = result.split()
    return words

def writeFile(s,num):
    """
    :param s: filename to write
    :param num: write content
    :return:
    """
    file_name = s
    my_open = open(file_name, 'a')
    # 打开fie_name路径下的my_infor.txt文件,采用追加模式
    # 若文件不存在,创建，若存在，追加
    my_open.write(num)
    my_open.write('\n')
    my_open.close()

    ##检查是否正确追加
    my_open = open(file_name, 'r')
    # 读取file_name路径下的my_write.txt文件
    my_infor = my_open.readlines()
    my_open.close()

if __name__ == "__main__":
    sys.setrecursionlimit(80000)
    pathname = "pride-and-prejudice.txt"
    words = readFile(pathname)
    print("----------Selection Sort----------")
    print(len(words))
    a = list(words)
    starttime = time.time_ns()
    MySort.quickSort(a)
    endtime = time.time_ns()
    print("sorted:", a)
    # print("unsorted:", words)
    filename = "selection sort.txt"
    print(endtime - starttime, "ns")
    writeFile(filename, str(endtime-starttime))
    # print("----------Insert Sort-------------")
    # b = list(words)
    # MySort.insertSort(b)
    # print("sorted:", b)
    # print("unsorted:", words)
    # print("--------In Place Heap Sort--------")
    # c = list(words)
    # MySort.in_place_HeapSort(c)
    # print("sorted:", c)
    # print("unsorted:", words)
    # print("------------Merge Sort------------")
    # d = list(words)
    # MySort.mergeSort(d)
    # print("sorted:", d)
    # print("unsorted:", words)
    # print("------------Quick Sort------------")
    # e = list(words)
    # MySort.quickSort(e)
    # print("sorted:", e)
    # print("unsorted:", words)
    # print("----------Are they same?----------")
    # print(a==b==c==d==e)
    #
    #
